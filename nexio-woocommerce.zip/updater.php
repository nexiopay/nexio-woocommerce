<?php

class NexioUpdater
{
    protected $file;
    protected $plugin;
    protected $active;

    private $username;
    private $repository;
    private $github_response;
    private $basename;
    private $slug;
    private $pluginName;

    public function __construct($file)
    {
        $this->file = $file;
        add_action('admin_init', array( $this, 'set_plugin_properties' ));
        return $this;
    }

    public function initialize()
    {

        add_filter('site_transient_update_plugins', array( $this, 'modify_transient' ));
        add_filter('transient_update_plugins', array( $this, 'modify_transient' ));

        add_filter('plugins_api', array( $this, 'plugin_popup' ), 10, 3);
        add_filter('upgrader_post_install', array( $this, 'after_install' ), 10, 3);
    }

    public function set_plugin_properties()
    {
        $this->plugin   = get_plugin_data($this->file);
        $this->basename = plugin_basename($this->file);
        $this->active   = is_plugin_active($this->basename);

        $this->pluginName = dirname($this->basename);
        $this->slug = $this->basename;
    }

    public function set_username($username)
    {
        $this->username = $username;
    }

    public function set_repository($repository)
    {
        $this->repository = $repository;
    }

    public function set_basename($basename)
    {
        $this->basename = $basename;
    }

    public function get_repository_info()
    {
        if (is_null($this->github_response)) { // Do we have a response?
            $request_uri = sprintf('https://api.github.com/repos/%s/%s/releases', $this->username, $this->repository); // Build URI
            $response = json_decode(wp_remote_retrieve_body(wp_remote_get($request_uri)), true); // Get JSON and parse it
            if (is_array($response)) { // If it is an array
                $response = current($response); // Get the first item
            }
            $this->github_response = $response; // Set it to our property
        }
    }

    public function modify_transient($update_plugins)
    {

        if (! is_object($update_plugins)) {
            return $update_plugins;
        }

        if (! isset($update_plugins->response) || ! is_array($update_plugins->response)) {
            $update_plugins->response = array();
        }

        if ($checked = $update_plugins->checked) { // Did WordPress check for updates?
            $this->get_repository_info();
            $out_of_date = 0;

            if (!empty($this->github_response['tag_name']) && !empty($checked[$this->basename])) {
                $out_of_date = version_compare($this->github_response['tag_name'], $checked[$this->basename], 'gt'); // Check if we're out of date
            }
            if ($out_of_date == 1) {
                $install_directory = basename(dirname(__FILE__));

                $package = 'https://github.com/nexiopay/' . $this->repository . '/archive/refs/tags/' . $this->github_response['tag_name'] . ".zip";
                $url = 'https://github.com/nexiopay/' . $this->repository;

                $update_plugins->response[$install_directory . '/nexio-init.php'] = (object)array(
                    'slug' => $this->slug,
                    'new_version' => $this->github_response['tag_name'],
                    'url' => $url,
                    'package' => $package
                );
            }
        }
        return $update_plugins;
    }

    public function plugin_popup($result, $action, $args)
    {
        if (! empty($args->slug)) {
            if ($args->slug == $this->slug) {
                $this->get_repository_info();
                $plugin = array(
                    'name'              => $this->plugin["Name"],
                    'slug'              => $this->basename,
                    'version'           => $this->github_response['tag_name'],
                    'author'            => $this->plugin["AuthorName"],
                    'author_profile'    => $this->plugin["AuthorURI"],
                    'last_updated'      => $this->github_response['published_at'],
                    'homepage'          => $this->plugin["PluginURI"],
                    'short_description' => $this->plugin["Description"],
                    'sections'          => array(
                        'Description'   => $this->plugin["Description"],
                        'Updates'       => $this->github_response['body'],
                    ),
                    'download_link'     => $this->github_response['zipball_url']
                );
                return (object) $plugin;
            }
        }
        return $result;
    }

    public function recurse_copy($src, $dst)
    {
        $dir = opendir($src);
        @mkdir($dst);
        while (false !== ( $file = readdir($dir))) {
            if (( $file != '.' ) && ( $file != '..' )) {
                if (is_dir($src . '/' . $file)) {
                    $this->recurse_copy($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
    public function removeDir($dirname)
    {
        if (is_dir($dirname)) {
            $dir = new RecursiveDirectoryIterator($dirname, RecursiveDirectoryIterator::SKIP_DOTS);
            foreach (new RecursiveIteratorIterator($dir, RecursiveIteratorIterator::CHILD_FIRST) as $object) {
                if ($object->isFile()) {
                    unlink($object);
                } elseif ($object->isDir()) {
                    rmdir($object);
                } else {
                    throw new Exception('Unknown object type: ' . $object->getFileName());
                }
            }
            rmdir($dirname);
        }
    }

    public function after_install($response, $hook_extra, $result)
    {
        global $wp_filesystem; // Get global FS object

        if (!empty($result['destination_name']) && (strpos($result['destination_name'], 'nexio-woocommerce')  === false)) {
            return $result;
        }

        $zipFile = $result['destination'] . "/nexio-woocommerce.zip";

        $pluginDirName = dirname($result['destination']);

        $latest = $pluginDirName . '/' . $this->pluginName . '_latest';
        if (file_exists($latest)) {
            $this->removeDir($latest);
        }
        mkdir($latest, 0777);

        $zip = new ZipArchive();
        $openZip = $zip->open($zipFile);

        if ($openZip === true) {
            $zip->extractTo($latest);

            $zip->close();

            if (!file_exists($pluginDirName . '/' . $this->pluginName)) {
                mkdir($pluginDirName . '/' . $this->pluginName);
            }

            $this->recurse_copy($latest, $pluginDirName . '/' . $this->pluginName);

            if (file_exists($latest)) {
                $this->removeDir($latest);
            }

            if (file_exists($result['destination'])) {
                $this->removeDir($result['destination']);
            }
        }

        return $result;
    }
}
