<?php
use PHPUnit\Framework\TestCase;
require "./nexio-utils.php";

final class NexioUtilsTest extends TestCase
{
    public function testSanitizeCurrentUrl(){
        $url = sanitize_current_url("/?wc-ajax=update_order_review");
        $this->assertEquals('', $url);

        $url = sanitize_current_url("@/asd-asd/00/?/wpnonce=xx");
        $this->assertEquals('asd-asd', $url);

        $url = sanitize_current_url("@/xxx-asd/00/?/wc_order=xx");
        $this->assertEquals('xxx-asd', $url);
    }


    public function testgetStatusFromApiResponseSuccess(){
        $result = '{"id":"eyJuYW1lIjoibmV4aW9fYXV0byIsIm1lcmNoYW50SWQiOiIzMDEwNzAiLCJyZWZOdW1iZXIiOiI0ZmE3NmQwOS1iZjkwLTRmYTItOTgyYS0wOTE1NjgwNDY3NTciLCJyYW5kb20iOjAsImN1cnJlbmN5IjoidXNkIn0="
        ,"merchantId":"301070","transactionDate":"2022-01-28T19:37:16.723Z","authCode":"P1N01I","transactionStatus":"settled","amount":"2.22","transactionType":"sale","currency":"USD",
        "gatewayResponse":{"refNumber":"4fa76d09-bf90-4fa2-982a-091568046757","gatewayName":"nexio_auto"},"data":{"amount":"2.22","currency":"USD","settlementCurrency":"USD",
        "customer":{"orderNumber":"43","firstName":"asd","lastName":"asd","billToAddressOne":"3400 S Ave 7th E","billToAddressTwo":"LOT 171","billToCity":"Yuma","billToState":"AZ",
        "billToPostal":"85365","billToCountry":"US","email":"rparies@cmsonline.com","phone":"256 555 1212","shipToAddressOne":"","shipToAddressTwo":"","shipToCity":"","shipToState":"",
        "shipToPostalCode":"","shipToCountry":""},"cart":{"items":[{"item":"two","quantity":1,"price":"2.22","type":"sale"}]}},"card":{"cardNumber":"411111******1111","cardType":"visa",
        "expirationYear":"2026","expirationMonth":"05","cardHolder":"Randy Test"},"token":{"firstSix":"411111","lastFour":"1111","token":"900cdffc-2751-43d3-a1ef-dcb4923b9d2b"},
        "random-6421681":"98a62ae7-bbed-4540-83c6-1380975976da"}';

        $result = json_decode($result, true);

        $gatewayStatus = getStatusFromApiResponse($result);

        $this->assertEquals($gatewayStatus, 'processing');
    }

    public function testGetStatusFromApiResponseDecline(){
        $result = '{"error":435,"message":"Insufficient funds. You are getting a decline because you are using card #400030******2220","gatewayResponse":{"gatewayName":"nexio_auto",
        "status":"declined"},"merchantId":"301070","random-8005143":"80fbe192-e068-469f-ad00-8876c57999ef"}';

        $result = json_decode($result, true);

        $gatewayStatus = getStatusFromApiResponse($result);

        $this->assertEquals($gatewayStatus, 'declined');
    }


    public function testNexioFilterResponseList(){
        $response = 'Card number error. You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Card declined, card information entered is incorrect.');

        $response = 'Do not Honor. You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Card declined, please use another card.');

        $response = 'Credit card has expired. You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Card declined, card information entered is incorrect.');

        $response = 'Insufficient funds. You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Card declined, insufficient funds.');

        $response = 'Unauthorized. You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Unauthorized credentials. Please contact support.');

        $response = 'Kount error You are getting a decline because you are using card #400030******2220';
        $sanatized = nexio_filter_response_list($response);
        $this->assertEquals($sanatized, 'Please try with a different card.');
    }

    public function testNexioSanitizeGatewayResponse(){
        $response = 'Card number error. You are getting a decline because you are using card #400030******2220';
        $message = nexio_sanitize_gateway_response($response, 1);
        $this->assertEquals($message, 'Card number error. You are getting a decline because you are using card #400030******2220');

        $message = nexio_sanitize_gateway_response($response, 0);
        $this->assertEquals($message, 'Card declined, card information entered is incorrect.');

    }

    public function testNexioSanitizeGatewayMessage(){
        $messageResponse = 'Invalid payment request. Please check your request or contact integration support.';
        $message = nexio_sanitize_gateway_message($messageResponse, 'yes');
        $this->assertEquals($message, 'Invalid payment request. "Send country as tag" is checked but the payment option tag is not setup on this account. Please check your request or contact integration support.');

        $message = nexio_sanitize_gateway_message($messageResponse, '');
        $this->assertEquals($message, 'Invalid payment request. Please check your request or contact integration support.');

    }

}