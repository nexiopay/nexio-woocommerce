<?php
use PHPUnit\Framework\TestCase;
require "./updater.php";

class UpdaterTest extends TestCase
{
    public function setUp(): void {
        parent::setUp();
        Brain\Monkey\setUp();
    }

    public function tearDown(): void {
        Brain\Monkey\tearDown();
        parent::tearDown();
    }

    public function test_sample() {
        $this->assertTrue( true );
    }

    public function test_constuctor(){
        $class = new NexioUpdater("thefile");
        $this->assertEquals( 10, has_action( 'admin_init', [ $class, 'set_plugin_properties' ] ) );
    }

    public function test_set_username(){
        $class = new NexioUpdater("thefile");
        $class->set_username('theusername');
        $property = $this->getPrivateProperty( 'NexioUpdater', 'username' );

        $this->assertEquals( $property->getValue( $class ), 'theusername' );
    }

    public function test_set_repository(){
        $class = new NexioUpdater("therepo");
        $class->set_repository('therepo');
        $property = $this->getPrivateProperty( 'NexioUpdater', 'repository' );

        $this->assertEquals( $property->getValue( $class ), 'therepo' );
    }

    public function test_set_basename(){
        $class = new NexioUpdater("therepo");
        $class->set_basename('thebasename');
        $property = $this->getPrivateProperty( 'NexioUpdater', 'basename' );

        $this->assertEquals( $property->getValue( $class ), 'thebasename' );
    }

    public function test_modify_transientNewVersion(){

        $mock =  $this->getMockBuilder('NexioUpdater')
            ->disableOriginalConstructor()
            ->onlyMethods(array('get_repository_info'))
            ->disableOriginalClone()
            ->disableArgumentCloning()
            ->disallowMockingUnknownTypes()
            ->getMock();

        $mock->set_basename('nexio-woocommerce/nexio-init.php');

        $dir = dirname(__FILE__);
        $paths = explode('/',$dir);

        $topLevel = $paths[ sizeof($paths) - 2 ];

        $install_directory = basename("../../".dirname(__FILE__));

        $object = new stdClass();
        $object->last_checked = '1644506727';
        $object->checked = [
            "akismet/akismet.php" => "4.2.1",
            "hello.php" => "1.7.2",
            "nexio-woocommerce/nexio-init.php" => "1.1.36",
            "woocommerce/woocommerce.php" => "6.1.0"
        ];

        $this->setPrivateProperty( 'NexioUpdater', 'github_response', [
            'tag_name' => '1.1.37'
        ] , $mock);

        $update_plugins = $mock->modify_transient($object);

        $this->assertEquals( $update_plugins->response[$topLevel.'/nexio-init.php']->new_version, '1.1.37' );

        $this->assertTrue( true );
    }
    public function test_modify_transientNotNewVersion(){

        $mock =  $this->getMockBuilder('NexioUpdater')
            ->disableOriginalConstructor()
            ->onlyMethods(array('get_repository_info'))
            ->disableOriginalClone()
            ->disableArgumentCloning()
            ->disallowMockingUnknownTypes()
            ->getMock();

        $mock->set_basename('nexio-woocommerce/nexio-init.php');

        $object = new stdClass();
        $object->last_checked = '1644506727';
        $object->checked = [
            "akismet/akismet.php" => "4.2.1",
            "hello.php" => "1.7.2",
            "nexio-woocommerce/nexio-init.php" => "1.1.36",
            "woocommerce/woocommerce.php" => "6.1.0"
        ];

        $this->setPrivateProperty( 'NexioUpdater', 'github_response', [
            'tag_name' => '1.1.36'
        ] , $mock);

        $update_plugins = $mock->modify_transient($object);

        $this->assertTrue( empty($update_plugins->response) );

        $this->assertTrue( true );
    }

    public function getPrivateProperty( $className, $propertyName ) {
        $reflector = new ReflectionClass( $className );
        $property = $reflector->getProperty( $propertyName );
        $property->setAccessible( true );

        return $property;
    }

    public function setPrivateProperty( $className, $propertyName, $value, $obj ) {
        $reflector = new ReflectionClass( $className );
        $reflectionProperty = $reflector->getProperty($propertyName);
        $reflectionProperty->setAccessible(true);
        $reflectionProperty->setValue($obj, $value);

    }
}