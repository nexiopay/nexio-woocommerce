<?php

function sanitize_current_url($url)
{
    //Sanitizing current URL so it returns order-pay instead of the full AJAX request
    preg_match('@/(\w+\-\w+)/\d+/\?.+?(?:(wpnonce=.+?|wc_order.+?))?$@si', $url, $match);
    if (!empty($match) && $match[1]) {
        return $match[1];
    }
}

function getStatusFromApiResponse($result)
{
    $transactionStatus = "";
    if (!empty($result['error'])) {
        $transactionStatus = $result['gatewayResponse']['status'];
    } else {
        if ($result['transactionStatus'] === 'pending' || $result['transactionStatus'] === 'settled') {
            $transactionStatus = "processing";
        } else {
            $transactionStatus = $result['transactionStatus'];
        }
    }
    return $transactionStatus;
}

function nexio_sanitize_gateway_response($response, $developmentMode)
{
    if (!empty($response)) {
        $filteredResponseMessage = nexio_filter_response_list($response);
        $message = $developmentMode ? $response : $filteredResponseMessage;
        return $message;
    }
}

function nexio_filter_response_list($response)
{
    if (strpos($response, 'Card number error') !== false) {
        return 'Card declined, card information entered is incorrect.';
    } elseif (strpos($response, 'Do not Honor') !== false) {
        return 'Card declined, please use another card.';
    } elseif (strpos($response, 'Credit card has expired') !== false) {
        return 'Card declined, card information entered is incorrect.';
    } elseif (strpos($response, 'Insufficient funds') !== false) {
        return 'Card declined, insufficient funds.';
    } elseif (strpos($response, 'Verify CVC Failed') !== false) {
        return 'Card declined, card information entered is incorrect.';
    } elseif (strpos($response, 'Unauthorized') !== false) {
        return 'Unauthorized credentials. Please contact support.';
    } elseif (strpos($response, 'Kount error') !== false) {
        return 'Please try with a different card.';
    } else {
        return 'Card declined, card information entered is incorrect.';
    }
}

function nexio_sanitize_gateway_message($message, $sendCountryAsTag)
{
    if (!empty($message)) {
        if ($sendCountryAsTag === 'yes') {
            if (strpos($message, 'Invalid payment request') !== false) {
                return 'Invalid payment request. "Send country as tag" is checked but the payment option tag is not setup on this account. Please check your request or contact integration support.';
            }
        } else {
            return $message;
        }
    }
}
